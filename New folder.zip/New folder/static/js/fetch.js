$(document).ready(function() {
    $('form').on('submit', function(event) {
        $ajax({
            data: {
                title: $('#headline').val() ,
                text: $('#comment').val()
            },
            type: 'GET',
            type: 'POST',
            url: '/'
        })
        .done(function(data) {

            if(data.error) {

                $('#op_title').hide();
                $('#op_text').hide();
                $('#op_error').text(data.error).show();

            }

            else {
                $('#op_title').text(data.title).show();
                $('#op_text').text(data.text).show();
                $('#op_error').hide();
            }
                
        });
        event.preventDefault();
    });
});